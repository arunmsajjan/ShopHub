
DROP INDEX idx_reviews_product_id;
DROP INDEX idx_reviews_user_id;
DROP INDEX idx_wishlists_product_id;
DROP INDEX idx_wishlists_user_id;
DROP TABLE reviews;
DROP TABLE wishlists;
DROP TABLE user_profiles;
