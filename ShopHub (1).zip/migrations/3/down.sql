
DROP INDEX idx_cart_user_id;
ALTER TABLE cart DROP COLUMN user_id;
