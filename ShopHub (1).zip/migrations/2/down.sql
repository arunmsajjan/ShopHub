
DROP INDEX idx_cart_product_id;
DROP TABLE cart;
